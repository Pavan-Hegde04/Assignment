#include<stdio.h>
#include<stdlib.h>

struct Node
{
	int data;
	struct Node* next;
	struct Node* prev;
};
struct Node *head;

void insert_begin()
{
	struct Node *ptr,*temp;
	int x;	
	ptr=(struct Node *)malloc(sizeof(struct Node *));
	if(ptr==NULL)
	{
		printf("\nOverflow");
	}
	else
	{
		printf("\nEnter value : \n");
		scanf("%d",&x);
		if(head==NULL)
		{
			ptr->next=NULL;
			ptr->prev=NULL;			
			ptr->data=x;			
			head=ptr;
		}
		else
		{
			ptr->data=x;
			ptr->prev=NULL;
			ptr->next=head;
			head->prev=ptr;
			head=ptr;
		}
		printf("\nNode inserted\n");
	}
}

void insert_last()
{
	struct Node *ptr,*temp;
	int x;
	ptr=(struct Node *)malloc(sizeof(struct Node *));
	if(ptr==NULL)
	{
		printf("\nOverflow");
	}
	else
	{
		printf("\nEnter value : \n");
		scanf("%d",&x);
		ptr->data=x;
		if(head==NULL)
		{
			ptr->prev=NULL;
			ptr->next=NULL;
			head=ptr;
		}
		else
		{
			temp=head;
			while(temp->next!=NULL)
			{
				temp=temp->next;
			}
			temp->next=ptr;
			ptr->prev=temp;
			ptr->next=NULL;
		}
		printf("\nNode inserted\n");
	}
}

void insert_rand()
{
	int x,loc,i;
	struct Node *ptr,*temp;
	ptr=(struct Node *)malloc(sizeof(struct Node *));
	if(ptr==NULL)
	{
		printf("\nOverflow");
	}
	else
	{
		printf("\nEnter the location after which you want to insert \n");
		scanf("%d",&loc);
		temp=head;
		for(i=0;i<loc;i++)
		{
			temp=temp->next;
			if(temp==NULL)
			{
				printf("\ninvalid\n");
				return;
			}
		}
		printf("\nEnter value : \n");
		scanf("%d",&x);
		ptr->data=x;
		ptr->next=temp->next;
		ptr->prev=temp;
		temp->next=ptr;
		temp->next->prev=ptr;
		printf("\nNode inserted\n");
	}	
}

void delete_begin()
{
	struct Node *ptr;
	if(head==NULL)
	{
		printf("\nempty list");
	}
	else if(head->next==NULL)
	{
		head=NULL;
		free(head);
		printf("\ndeleted node is the only in the list");
	}
	else
	{
		ptr=head;
		head=head->next;
		head->prev=NULL;
		free(ptr);
		printf("\nNode has been deleted at the begining..\n");
	}
}

void delete_last()
{
	struct Node *ptr;
	if(head==NULL)
	{
		printf("\nempty list");
	}
	else if(head->next==NULL)
	{
		head=NULL;
		free(head);
		printf("\ndeleted node is the only in the list");
	}
	else
	{
		ptr=head;
		if(ptr->next!=NULL)
		{
			ptr=ptr->next;
		}
		ptr->prev->next=NULL;
		free(ptr);
		printf("\nNode has been deleted at the last pos..\n");
	}
}

void display()
{
	struct Node *ptr;
	ptr=head;
	if(head==NULL)
	{
		printf("No elements\n");
	}
	else
	{
		while(ptr!=NULL)
		{
			printf("\n%d",ptr->data);
			ptr=ptr->next;
		}
		printf("\n%d",ptr->data);
	}
}

void main()
{
	int ch=0;
	while(ch!=9)
	{
		printf("\nchoose options below\n");
		printf("\n1.Insert node & data at begining\n2.Insert node & data at last\n3.Insert node & data at random location(0 to n)\n4.Display\n5.Delete node at begining\n6.Delete node at	last\n7.exit\n");
		scanf("\n%d",&ch);
		switch(ch)
		{
			case 1:
				insert_begin();
				break;
			case 2:
				insert_last();
				break;
			case 3:
				insert_rand();
				break;
			case 4:
				display();
				break;
			case 5:
				delete_begin();
				break;
			case 6:
				delete_last();
				break;
			case 7:
				exit(0);
				break;
			default:
				printf("invalid option");
		}
	}		
}
