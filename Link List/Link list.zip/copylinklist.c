#include <stdio.h>
#include <stdlib.h>

typedef struct LinkNode
{
	int data;
	struct LinkNode * next;
}LinkNode;

LinkNode * getLinkNode(int data, LinkNode * top)
{
	LinkNode * ref = (LinkNode * ) malloc(sizeof(LinkNode));
	if (ref == NULL)
	{ 
		return NULL;
	}
	ref->data = data;
	ref->next = top;
	return ref;
}
typedef struct SingleLL
{
	struct LinkNode * head;
}SingleLL;

SingleLL * getSingleLL()
{
	SingleLL * ref = (SingleLL * ) malloc(sizeof(SingleLL));
	if (ref == NULL)
	{ 
		return NULL;
	}
	ref->head = NULL;
	return ref;
}

void addNode(SingleLL * ref, int data)
{
	ref->head = getLinkNode(data, ref->head);
}

void display(SingleLL * ref)
{
	if (ref->head == NULL)
	{
		return;
	}
	LinkNode * temp = ref->head;
	
	while (temp != NULL)
	{
		printf("\n%d", temp->data);
		temp = temp->next;
	}
	printf("\nNULL\n");
}
SingleLL * cloneList(SingleLL * ref)
{
	SingleLL * result = getSingleLL();
	LinkNode * node = ref->head;
	LinkNode * tail = NULL;
	while (node != NULL)
	{
		if (result->head == NULL)
		{
			result->head = getLinkNode(node->data, NULL);
			tail = result->head;
		}
		else
		{
			tail->next = getLinkNode(node->data, NULL);
			tail = tail->next;
		}
		node = node->next;
	}
	return result;
}
void main()
{
	SingleLL * sll = getSingleLL();
	int x;
	for(int i=0;i<6;i++)
	{
		printf("\nEnter value : \n");
		scanf("%d",&x);
		addNode(sll, x);
	}
	printf("\nOriginal Link List : ");
	display(sll);
	SingleLL * copy = cloneList(sll);
	printf("\ncopied!!!\n");
	display(copy);		
}
